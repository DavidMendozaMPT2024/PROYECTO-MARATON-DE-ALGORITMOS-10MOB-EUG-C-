// ex19_rpn_calculator.cpp
#include <iostream>
#include <stack>
#include <sstream>
using namespace std;
// Leer una expresion RPN (tokens separados por espacios) y calcular resultado.
int main(){
    string line; cout<<"Ingrese expresion RPN (ej: 3 4 + 2 *):\n";
    getline(cin,line);
    if(line.empty()) getline(cin,line);
    istringstream ss(line);
    stack<double> st; string tk;
    while(ss>>tk){
        if(string("+-*/").find(tk)!=string::npos && st.size()>=2){
            double b=st.top(); st.pop(); double a=st.top(); st.pop();
            if(tk=="+") st.push(a+b);
            else if(tk=="-") st.push(a-b);
            else if(tk=="*") st.push(a*b);
            else if(tk=="/") st.push(a/b);
        } else {
            st.push(stod(tk));
        }
    }
    if(!st.empty()) cout<<"Resultado: "<<st.top()<<"\n";
    else cout<<"Expresion invalida\n";
}
