// ex16_substring_search.cpp
#include <iostream>
#include <vector>
#include <string>
using namespace std;
// Implementa prefijos (como KMP) para buscar pattern en text.
vector<int> prefix_function(const string& s){
    int n=s.size(); vector<int> pi(n);
    for(int i=1;i<n;i++){
        int j=pi[i-1];
        while(j>0 && s[i]!=s[j]) j=pi[j-1];
        if(s[i]==s[j]) j++;
        pi[i]=j;
    }
    return pi;
}
int main(){
    string t,p; cout<<"Texto: "; getline(cin,t);
    cout<<"Patron: "; getline(cin,p);
    string s = p + "#" + t;
    auto pi = prefix_function(s);
    bool found=false;
    for(int i=0;i<(int)pi.size();i++) if(pi[i]==(int)p.size()){ found=true; break; }
    cout<<(found?"Encontrado\n":"No encontrado\n");
}
