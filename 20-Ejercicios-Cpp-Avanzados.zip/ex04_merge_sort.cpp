// ex04_merge_sort.cpp
#include <iostream>
#include <vector>
using namespace std;
void merge_sort(vector<int>& a, int l, int r){
    if(l>=r) return;
    int m = (l+r)/2;
    merge_sort(a,l,m);
    merge_sort(a,m+1,r);
    vector<int> tmp; int i=l,j=m+1;
    while(i<=m && j<=r){
        if(a[i]<=a[j]) tmp.push_back(a[i++]); else tmp.push_back(a[j++]);
    }
    while(i<=m) tmp.push_back(a[i++]);
    while(j<=r) tmp.push_back(a[j++]);
    for(size_t k=0;k<tmp.size();k++) a[l+k]=tmp[k];
}
int main(){
    int n; cout<<"N: "; cin>>n;
    vector<int> a(n);
    for(int i=0;i<n;i++) cin>>a[i];
    merge_sort(a,0,n-1);
    cout<<"Ordenado: ";
    for(int v:a) cout<<v<<" ";
    cout<<"\n";
}
