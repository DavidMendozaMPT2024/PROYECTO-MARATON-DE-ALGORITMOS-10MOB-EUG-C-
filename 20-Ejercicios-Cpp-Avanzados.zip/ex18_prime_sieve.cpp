// ex18_prime_sieve.cpp
#include <iostream>
#include <vector>
using namespace std;
int main(){
    int N; cout<<"N: "; cin>>N;
    vector<bool> isprime(N+1,true); isprime.assign(N+1,true);
    if(N>=0) isprime[0]=false; if(N>=1) isprime[1]=false;
    for(int i=2;i*i<=N;i++) if(isprime[i]) for(int j=i*i;j<=N;j+=i) isprime[j]=false;
    cout<<"Primos hasta "<<N<<": ";
    for(int i=2;i<=N;i++) if(isprime[i]) cout<<i<<" ";
    cout<<"\n";
}
