// ex13_dijkstra.cpp
#include <iostream>
#include <vector>
#include <queue>
using namespace std;
using pii = pair<long long,int>;
const long long INF = 4e18;
int main(){
    int n,m; cin>>n>>m;
    vector<vector<pair<int,int>>> g(n);
    for(int i=0;i<m;i++){ int u,v,w; cin>>u>>v>>w; g[u].push_back({v,w}); g[v].push_back({u,w}); }
    int s; cin>>s;
    vector<long long> dist(n,INF); dist[s]=0;
    priority_queue<pii, vector<pii>, greater<pii>> pq; pq.push({0,s});
    while(!pq.empty()){
        auto [d,u]=pq.top(); pq.pop();
        if(d>dist[u]) continue;
        for(auto [v,w]: g[u]){
            if(dist[v]>dist[u]+w){ dist[v]=dist[u]+w; pq.push({dist[v],v}); }
        }
    }
    cout<<"Distancias desde "<<s<<":\n";
    for(int i=0;i<n;i++) cout<<i<<": "<<(dist[i]==INF?-1:dist[i])<<"\n";
}
