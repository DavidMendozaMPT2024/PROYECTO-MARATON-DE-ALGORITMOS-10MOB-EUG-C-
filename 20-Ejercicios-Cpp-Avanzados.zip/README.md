# 20 Ejercicios C++ Avanzados - Pack3

Autor: David Mendoza (preparado por ChatGPT)

Carpeta: `20-Ejercicios-Cpp-Avanzados`

Contenido: 20 ejercicios totalmente nuevos y distintos a los anteriores. Cada ejercicio está en su propio archivo `.cpp`. Cada archivo incluye un `main()` y mensajes para usarlo desde consola.

Lista de ejercicios:
1. ex01_stack_simulator.cpp — Simula una pila (push/pop) con arreglo.
2. ex02_queue_simulator.cpp — Simula una cola circular básica.
3. ex03_binary_search.cpp — Búsqueda binaria en arreglo ordenado.
4. ex04_merge_sort.cpp — Implementación de Merge Sort.
5. ex05_linked_list.cpp — Lista enlazada simple (insertar/eliminar/mostrar).
6. ex06_complex_numbers_class.cpp — Clase `Complex` con operaciones.
7. ex07_matrix_multiplication.cpp — Multiplicación de matrices (NxM * MxP).
8. ex08_sudoku_checker.cpp — Verifica si una solución 9x9 es válida.
9. ex09_tic_tac_toe.cpp — Mini juego Tic-Tac-Toe para 2 jugadores en consola.
10. ex10_simple_database.cpp — Guardar/leer registros en archivo `db.txt`.
11. ex11_recursive_permutations.cpp — Genera permutaciones de una cadena.
12. ex12_graph_bfs_dfs.cpp — BFS y DFS en grafo representado con listas.
13. ex13_dijkstra.cpp — Ruta más corta (Dijkstra) en grafo con pesos.
14. ex14_knapsack_backtracking.cpp — Problema de la mochila por backtracking.
15. ex15_string_compression.cpp — Compresión simple tipo RLE.
16. ex16_substring_search.cpp — Búsqueda de subcadena (KMP-like simple).
17. ex17_date_validator.cpp — Valida fecha día/mes/año incluyendo bisiestos.
18. ex18_prime_sieve.cpp — Criba de Eratóstenes para primos hasta N.
19. ex19_rpn_calculator.cpp — Calculadora RPN (postfija) con pila.
20. ex20_simulated_threads.cpp — Simula "tareas" y su scheduling round-robin (sin hilos reales).

Instrucciones rápidas para usar:
1. Descomprime o copia los archivos en tu repo local dentro de la carpeta.
2. Compila individualmente, por ejemplo: `g++ ex01_stack_simulator.cpp -o ex01`
3. Ejecuta con `./ex01` y sigue las indicaciones por consola.

Puedes modificar nombres, agregar comentarios o integrarlos a un menú principal. Si quieres, te creo también un `Makefile` o un solo `menu.cpp` que invoque cada ejercicio.
