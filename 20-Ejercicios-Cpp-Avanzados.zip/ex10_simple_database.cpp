// ex10_simple_database.cpp
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
// Guarda registros "nombre|edad" en db.txt y permite listar.
int main(){
    int op; string name; int age;
    do{
        cout<<"\n1.Agregar 2.Listar 0.Salir\nOp: "; cin>>op;
        if(op==1){
            cout<<"Nombre: "; cin>>name; cout<<"Edad: "; cin>>age;
            ofstream f("db.txt", ios::app);
            f<<name<<"|"<<age<<"\n";
            f.close();
            cout<<"Guardado\n";
        } else if(op==2){
            ifstream f("db.txt");
            string line;
            cout<<"Registros:\n";
            while(getline(f,line)) cout<<line<<"\n";
            f.close();
        }
    } while(op!=0);
}
